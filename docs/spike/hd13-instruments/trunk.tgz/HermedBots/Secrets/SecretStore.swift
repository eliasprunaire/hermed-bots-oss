import Foundation
import Security

/// Là où l'app lit les clés : celle de l'API Hermes et la clé privée SSH du tunnel
protocol SecretStore {
    func apiKey() throws -> String?
    func sshPrivateKey() throws -> String?
}

/// Magasin du mode test (`HV_TEST_MODE=1`) : il ne touche jamais le Trousseau
struct InMemorySecretStore: SecretStore {
    let key: String?
    let sshKey: String?

    init(apiKey: String?, sshKey: String? = nil) {
        key = apiKey
        self.sshKey = sshKey
    }

    func apiKey() throws -> String? { key }

    func sshPrivateKey() throws -> String? { sshKey }
}

struct KeychainError: Error, CustomStringConvertible {
    let status: OSStatus

    var description: String {
        "Trousseau : \(SecCopyErrorMessageString(status, nil) as String? ?? "erreur \(status)")"
    }
}

/// Clés dans le Trousseau de l'utilisateur ; la première saisie réelle reste manuelle (A3)
struct KeychainSecretStore: SecretStore {
    static let service = "com.hermedbots.HermedBots"
    static let account = "hermes-api-key"
    static let sshAccount = "hermes-ssh-key"

    func apiKey() throws -> String? { try read(account: Self.account) }

    func sshPrivateKey() throws -> String? { try read(account: Self.sshAccount) }

    private func read(account: String) throws -> String? {
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: Self.service,
            kSecAttrAccount: account,
            kSecReturnData: true,
            kSecMatchLimit: kSecMatchLimitOne,
        ]
        var item: CFTypeRef?
        switch SecItemCopyMatching(query as CFDictionary, &item) {
        case errSecSuccess: return (item as? Data).flatMap { String(data: $0, encoding: .utf8) }
        case errSecItemNotFound: return nil
        case let status: throw KeychainError(status: status)
        }
    }
}
