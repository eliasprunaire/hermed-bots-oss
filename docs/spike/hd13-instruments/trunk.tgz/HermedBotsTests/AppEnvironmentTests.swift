import XCTest

// compilé dans le paquet de tests lui-même, sans l'app comme hôte : lancer ces tests ne démarre pas l'app, donc ne lit jamais le Trousseau
final class AppEnvironmentTests: XCTestCase {
    /// Échoue dès que quelqu'un le construit ou le lit
    private final class SpyKeychain: SecretStore {
        func apiKey() throws -> String? {
            XCTFail("KeychainSecretStore appelé")
            return nil
        }

        func sshPrivateKey() throws -> String? {
            XCTFail("KeychainSecretStore appelé")
            return nil
        }
    }

    private func isolatedDefaults() -> UserDefaults {
        let name = "hd07-tests-\(UUID().uuidString)"
        let defaults = UserDefaults(suiteName: name)!
        addTeardownBlock { UserDefaults(suiteName: name)?.removePersistentDomain(forName: name) }
        return defaults
    }

    private func spy() -> SecretStore {
        XCTFail("KeychainSecretStore construit")
        return SpyKeychain()
    }

    #if DEBUG
    func testTestModeInjectsTheInMemoryStoreAndNeverTouchesTheKeychain() throws {
        let environment = AppEnvironment.resolve(
            ["HV_TEST_MODE": "1", "HV_TEST_API_KEY": "cle-de-test-0123456789", "HV_API_URL": "http://127.0.0.1:18642"],
            keychain: spy
        )
        XCTAssertTrue(environment.secrets is InMemorySecretStore)
        XCTAssertEqual(try environment.secrets.apiKey(), "cle-de-test-0123456789")
        XCTAssertEqual(environment.baseURL, URL(string: "http://127.0.0.1:18642"))
    }

    func testTestModeWithoutAKeyHasNoKeyAndDoesNotFallBackToTheKeychain() throws {
        let environment = AppEnvironment.resolve(["HV_TEST_MODE": "1"], keychain: spy)
        XCTAssertNil(try environment.secrets.apiKey())
        XCTAssertNil(environment.baseURL)
    }

    func testTestModeReadsTheSSHEndpointAndTheKeyFromTheEnvironmentAndRefusesPersoHermes() throws {
        let environment = AppEnvironment.resolve(
            ["HV_TEST_MODE": "1", "HV_SSH_HOST": "hv-hermes-test.orb.local", "HV_SSH_USER": "hvssh", "HV_SSH_PORT": "2222", "HV_TEST_SSH_KEY": "cle-ssh-de-test"],
            defaults: isolatedDefaults(), keychain: spy
        )
        XCTAssertEqual(environment.ssh, SSHEndpoint(host: "hv-hermes-test.orb.local", user: "hvssh", port: 2222))
        XCTAssertEqual(try environment.secrets.sshPrivateKey(), "cle-ssh-de-test")
        XCTAssertTrue(environment.refusePersoHermes)
    }

    func testTheTunnelWinsOverTheDirectApiUrl() {
        let environment = AppEnvironment.resolve(
            ["HV_TEST_MODE": "1", "HV_SSH_HOST": "h.local", "HV_SSH_USER": "u", "HV_API_URL": "http://127.0.0.1:18642"],
            defaults: isolatedDefaults(), keychain: spy
        )
        XCTAssertNotNil(environment.ssh)
        XCTAssertNil(environment.baseURL, "avec un hôte SSH, l'app ne doit atteindre l'API que par le tunnel")
    }

    func testTestModeReadsTheMainThreadBlockToInjectAndIgnoresAValueThatIsNotANumber() {
        XCTAssertEqual(AppEnvironment.resolve(["HV_TEST_MODE": "1", "HV_HANG_MS": "400"], keychain: spy).testHangMilliseconds, 400)
        XCTAssertEqual(AppEnvironment.resolve(["HV_TEST_MODE": "1", "HV_HANG_MS": "abc"], keychain: spy).testHangMilliseconds, 0)
        XCTAssertEqual(AppEnvironment.resolve(["HV_TEST_MODE": "1"], keychain: spy).testHangMilliseconds, 0)
    }

    func testTestModeIgnoresTheStoredEndpoint() {
        let defaults = isolatedDefaults()
        SSHEndpoint(host: "stored.local", user: "stored", port: 22).save(to: defaults)
        let environment = AppEnvironment.resolve(["HV_TEST_MODE": "1"], defaults: defaults, keychain: spy)
        XCTAssertNil(environment.ssh, "le mode test ne lit pas les réglages de l'utilisateur")
    }

    func testAnInvalidSSHPortFallsBackToThePort22() {
        let environment = AppEnvironment.resolve(["HV_TEST_MODE": "1", "HV_SSH_HOST": "h.local", "HV_SSH_USER": "u", "HV_SSH_PORT": "abc"], defaults: isolatedDefaults(), keychain: spy)
        XCTAssertEqual(environment.ssh?.port, 22)
    }

    func testOnlyTheValueOneEnablesTestMode() {
        for value in ["0", "true", "yes", "", " 1"] {
            var built = false
            let environment = AppEnvironment.resolve(["HV_TEST_MODE": value, "HV_API_URL": "http://127.0.0.1:18642"], keychain: {
                built = true
                return SpyKeychain()
            })
            XCTAssertTrue(built, "HV_TEST_MODE=\(value) devrait laisser le Trousseau actif")
            XCTAssertFalse(environment.secrets is InMemorySecretStore)
            XCTAssertNil(environment.baseURL)
        }
    }
    #else
    func testReleaseIgnoresTestModeTheTestKeyAndTheApiUrl() {
        var built = false
        let environment = AppEnvironment.resolve(
            ["HV_TEST_MODE": "1", "HV_TEST_API_KEY": "cle-de-test-0123456789", "HV_API_URL": "http://127.0.0.1:18642", "HV_SSH_HOST": "h.local", "HV_SSH_USER": "u", "HV_TEST_SSH_KEY": "k"],
            defaults: isolatedDefaults(),
            keychain: {
                built = true
                return SpyKeychain()
            }
        )
        XCTAssertTrue(built, "la Release utilise le Trousseau même avec HV_TEST_MODE=1")
        XCTAssertFalse(environment.secrets is InMemorySecretStore)
        XCTAssertNil(environment.baseURL)
        XCTAssertNil(environment.ssh, "la Release ignore HV_SSH_HOST")
        XCTAssertFalse(environment.refusePersoHermes)
    }
    #endif

    func testWithoutTestModeTheKeychainIsUsedAndTheApiUrlIsIgnored() {
        var built = false
        let environment = AppEnvironment.resolve(["HV_API_URL": "http://127.0.0.1:18642"], keychain: {
            built = true
            return SpyKeychain()
        })
        XCTAssertTrue(built)
        XCTAssertFalse(environment.secrets is InMemorySecretStore)
        XCTAssertNil(environment.baseURL)
    }

    func testWithoutTestModeTheEndpointComesFromTheStoredSettingsAndTheEnvironmentIsIgnored() {
        let defaults = isolatedDefaults()
        SSHEndpoint(host: "perso.example", user: "ayo", port: 2200).save(to: defaults)
        let environment = AppEnvironment.resolve(
            ["HV_SSH_HOST": "evil.local", "HV_SSH_USER": "evil", "HV_SSH_PORT": "1", "HV_TEST_SSH_KEY": "x"],
            defaults: defaults, keychain: { SpyKeychain() }
        )
        XCTAssertEqual(environment.ssh, SSHEndpoint(host: "perso.example", user: "ayo", port: 2200))
        XCTAssertFalse(environment.refusePersoHermes, "perso-hermes est la cible réelle du produit")
        XCTAssertFalse(environment.secrets is InMemorySecretStore)
    }

    func testWithoutTestModeNoMainThreadBlockIsInjected() {
        let environment = AppEnvironment.resolve(["HV_HANG_MS": "400"], defaults: isolatedDefaults(), keychain: { SpyKeychain() })
        XCTAssertEqual(environment.testHangMilliseconds, 0)
    }

    func testWithoutAStoredHostThereIsNoTunnelToOpen() {
        let environment = AppEnvironment.resolve([:], defaults: isolatedDefaults(), keychain: { SpyKeychain() })
        XCTAssertNil(environment.ssh)
    }

    func testSavingThenReadingGivesTheSameEndpoint() {
        let defaults = isolatedDefaults()
        XCTAssertNil(SSHEndpoint.stored(in: defaults))
        let endpoint = SSHEndpoint(host: "h.local", user: "u", port: 2022)
        endpoint.save(to: defaults)
        XCTAssertEqual(SSHEndpoint.stored(in: defaults), endpoint)
    }
}
